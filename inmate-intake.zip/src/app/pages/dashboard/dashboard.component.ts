import { Component, OnInit, Inject } from '@angular/core';
import { DashboardService } from './dashboard-service.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Subscription } from 'rxjs';

@Component({
	selector: 'app-dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

	public datasets: any;
	public data: any;
	public salesChart;
	public clicked: boolean = true;
	public clicked1: boolean = false;
	public inmates: Array<any> = [];

	public gettingInmates: Subscription;

	constructor(public dashboardService: DashboardService, public dialog: MatDialog) { }

	ngOnInit() {
		this.gettingInmates = this.dashboardService.GetInmates().subscribe(
			data => {
				this.inmates = data;
			}, error => {

			}
		)
	}

	public OpenCreateInmateDialog(): void {
		const dialogRef = this.dialog.open(CreateInmateDialog, {
			width: '600px'
		});

		dialogRef.afterClosed().subscribe(result => {
			console.log('The dialog was closed');

		});
	}

	public ViewInmateDetails(item): void {
		const dialogRef = this.dialog.open(InmateDetailsDialog, {
			width: '600px',
			data: item
		});

		dialogRef.afterClosed().subscribe(result => {
			console.log('The dialog was closed');

		});
	}

	public trackByFunction(index, item) {
		if (!item)
			return null;
		return item.our_item_id;
	}

	public updateOptions() {
		this.salesChart.data.datasets[0].data = this.data;
		this.salesChart.update();
	}

}

@Component({
	selector: 'create-inmate-dialog',
	templateUrl: 'create-inmate-dialog.html',
})
export class CreateInmateDialog {

	public newInmate: any = {};

	constructor(
		public dialogRef: MatDialogRef<CreateInmateDialog>) { }

	onNoClick(): void {
		this.dialogRef.close();
	}
}

@Component({
	selector: 'inmate-details-dialog',
	templateUrl: 'inmate-details-dialog.html',
})
export class InmateDetailsDialog {

	constructor(
		public dialogRef: MatDialogRef<InmateDetailsDialog>,
		@Inject(MAT_DIALOG_DATA) public data: any) { }

	onNoClick(): void {
		this.dialogRef.close();
	}
}