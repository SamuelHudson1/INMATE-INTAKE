## [1.1.0] - 2020-03-06
### Updates
- update to Angular 9
- update all dependencies to match Angular 9 version


## [1.0.1] - 2019-08-05
### Bug fixing
- fix datepicker style

## [1.0.0] - 2019-03-14
### Initial Release
